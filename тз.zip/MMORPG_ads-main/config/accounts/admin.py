from django.contrib import admin

from .models import UsersCode


admin.site.register(UsersCode)
