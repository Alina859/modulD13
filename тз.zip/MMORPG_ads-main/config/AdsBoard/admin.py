from django.contrib import admin

from .models import Adv, Reply


admin.site.register(Adv)
admin.site.register(Reply)
